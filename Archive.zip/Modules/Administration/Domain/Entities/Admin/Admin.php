<?php

namespace Modules\Administration\Domain\Entities\Admin;

use App\Domain\Entities\User\User;

class Admin extends User
{
    protected $table = 'users';


}
