<?php

return [
    'name' => 'Administration'
];
