<?php

return [
    'name' => 'Courses'
];
