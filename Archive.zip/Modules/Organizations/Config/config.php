<?php

return [
    'name' => 'Organizations'
];
