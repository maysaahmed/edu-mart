<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Courses\\Providers\\CoursesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Courses\\Providers\\CoursesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);