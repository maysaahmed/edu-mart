<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Administration\\Providers\\AdministrationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Administration\\Providers\\AdministrationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);