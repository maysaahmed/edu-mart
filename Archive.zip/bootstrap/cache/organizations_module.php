<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Organizations\\Providers\\OrganizationsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Organizations\\Providers\\OrganizationsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);